import cv2
import face_recognition
import sqlite3
import numpy as np

# Function to capture an image from webcam
def capture_image():
    video_capture = cv2.VideoCapture(0)
    ret, frame = video_capture.read()
    video_capture.release()
    cv2.destroyAllWindows()
    return frame

# Function to detect face and get face encodings
def get_face_encodings(image):
    rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    face_locations = face_recognition.face_locations(rgb_image)
    face_encodings = face_recognition.face_encodings(rgb_image, face_locations)
    return face_encodings[0] if face_encodings else None

# Function to insert face encodings into the database
def store_face_encodings(name, encoding):
    conn = sqlite3.connect('face_recognition.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS faces (name TEXT, encoding TEXT)''')
    c.execute("INSERT INTO faces (name, encoding) VALUES (?, ?)", (name, str(encoding)))
    conn.commit()
    conn.close()

# Function to load face encodings from the database
def load_face_encodings():
    conn = sqlite3.connect('face_recognition.db')
    c = conn.cursor()
    c.execute("SELECT name, encoding FROM faces")
    rows = c.fetchall()
    known_face_names = []
    known_face_encodings = []
    for row in rows:
        name = row[0]
        encoding_str = row[1]
        encoding = np.fromstring(encoding_str[1:-1], sep=',')
        known_face_names.append(name)
        known_face_encodings.append(encoding)
    conn.close()
    return known_face_names, known_face_encodings

# Function to compare face encodings
def compare_face_enc(get_stored_names, get_stored_face_encodings, face_encoding):
    matches = face_recognition.compare_faces(get_stored_face_encodings, face_encoding)
    face_distances = face_recognition.face_distance(get_stored_face_encodings, face_encoding)
    best_match_index = np.argmin(face_distances)
    if matches[best_match_index]:
        return get_stored_names[best_match_index]
    else:
        return "Unknown"

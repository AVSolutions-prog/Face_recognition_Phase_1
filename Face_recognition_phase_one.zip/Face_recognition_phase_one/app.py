from flask import Flask, request, render_template, redirect, url_for
import os
from face_recognition_code import capture_image, get_face_encodings, store_face_encodings, load_face_encodings, compare_face_enc

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        image = capture_image()
        face_encoding = get_face_encodings(image)
        if face_encoding is not None:
            store_face_encodings(name, face_encoding.tolist())
            return redirect(url_for('index'))
        else:
            return "No face detected in the image."
    return render_template('register.html')

@app.route('/verify', methods=['GET', 'POST'])
def verify():
    if request.method == 'POST':
        image = capture_image()
        face_encoding = get_face_encodings(image)
        if face_encoding is not None:
            known_face_names, known_face_encodings = load_face_encodings()
            match_name = compare_face_enc(known_face_names, known_face_encodings, face_encoding)
            return render_template('verify.html', match_name=match_name)
        else:
            return "No face detected in the image."
    return render_template('verify.html', match_name=None)

if __name__ == '__main__':
    app.run(debug=True)

from flask import Flask, request, jsonify, render_template
import numpy as np
from face_recognition_util import (
    capture_image, change_bgr_rgb, detect_faces, get_face_embeddings,
    store_face_embedding, load_face_embeddings, calc_distance
)

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        try:
            frame = capture_image()
            print("Image captured successfully.")
            rgb_img = change_bgr_rgb(frame)
            print("Image converted to RGB.")
            face_loc = detect_faces(rgb_img)
            print(f"Faces detected: {face_loc}")

            if face_loc:
                embeddings = get_face_embeddings(rgb_img, face_loc)
                store_face_embedding(name, embeddings[0])
                print(f"Stored embedding for {name}.")
                return jsonify({"message": "Registration successful"}), 200
            else:
                return jsonify({"message": "No face detected"}), 400
        except Exception as e:
            return jsonify({"message": str(e)}), 500
    return render_template('register.html')

@app.route('/verify', methods=['GET', 'POST'])
def verify():
    if request.method == 'POST':
        try:
            frame = capture_image()
            print("Image captured successfully.")
            rgb_img = change_bgr_rgb(frame)
            print("Image converted to RGB.")
            face_loc = detect_faces(rgb_img)
            print(f"Faces detected: {face_loc}")

            if face_loc:
                embeddings = get_face_embeddings(rgb_img, face_loc)
                known_face_names, known_face_embeddings = load_face_embeddings()
                min_distance = float('inf')
                name = "Unknown"

                for known_name, known_embedding in zip(known_face_names, known_face_embeddings):
                    distance = calc_distance(embeddings[0], known_embedding)
                    if distance < min_distance:
                        min_distance = distance
                        name = known_name

                # Prepare the response
                response = {"name": name, "distance": min_distance}
                return jsonify(response), 200
            else:
                return jsonify({"message": "No face detected"}), 400
        except Exception as e:
            return jsonify({"message": str(e)}), 500
    return render_template('verify.html')


if __name__ == '__main__':
    app.run(debug=True)

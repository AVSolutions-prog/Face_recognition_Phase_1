import cv2
import numpy as np
import sqlite3
from keras_facenet import FaceNet
import face_recognition

# Initialize FaceNet model for creating face embeddings
face_embedder = FaceNet()

# Capture image using webcam with the help of OpenCV
def capture_image():
    video_capture = cv2.VideoCapture(0)
    ret, frame = video_capture.read()
    video_capture.release()
    return frame

# Convert BGR to RGB
def change_bgr_rgb(image):
    rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    return rgb_image

# Detect face using face_recognition
def detect_faces(rgb_image):
    face_locations = face_recognition.face_locations(rgb_image)
    return face_locations

# Function to resize and normalize the detected face and extract embeddings using FaceNet
def get_face_embeddings(rgb_image, face_locations):
    face_list = []  # Initialize an empty list
    for (top, right, bottom, left) in face_locations:  # Loop through the coordinates of face regions
        face = rgb_image[top:bottom, left:right]  # Crop the face region
        face = cv2.resize(face, (160, 160))  # Resize the cropped face to make it suitable for FaceNet
        face = face.astype('float32') / 255  # Normalize the face
        face_list.append(face)  # Append the face to the list
    embeddings = face_embedder.embeddings(face_list)  # Extract embeddings using FaceNet
    return embeddings  # Return the embeddings

# Store the extracted face embeddings and user name in the SQLite database
def store_face_embedding(name, embedding):
    conn = sqlite3.connect('face_recognition.db')  # Connect to the SQLite database
    c = conn.cursor()  # Create a cursor to execute the queries
    c.execute('''CREATE TABLE IF NOT EXISTS faces (name TEXT, encoding BLOB)''')  # Create a table if it doesn't exist
    c.execute("INSERT INTO faces (name, encoding) VALUES (?, ?)", (name, embedding.tobytes()))  # Insert the user name and embedding
    conn.commit()  # Commit the transaction
    conn.close()  # Close the connection

# Load stored face embeddings from the database
def load_face_embeddings():
    conn = sqlite3.connect('face_recognition.db')  # Connect to the SQLite database
    c = conn.cursor()  # Create a cursor to execute the queries
    c.execute("SELECT name, encoding FROM faces")  # Select the name and encoding from the table
    rows = c.fetchall()  # Fetch all rows
    known_face_names = []  # Initialize an empty list for names
    known_face_embeddings = []  # Initialize an empty list for embeddings
    for row in rows:
        name = row[0]  # Extract name
        encoding_blob = row[1]  # Extract encoding
        encoding = np.frombuffer(encoding_blob, dtype=np.float32)  # Convert encoding from blob to numpy array
        known_face_names.append(name)  # Append name to the list
        known_face_embeddings.append(encoding)  # Append encoding to the list
    conn.close()  # Close the connection
    return known_face_names, known_face_embeddings  # Return names and embeddings

# Function to calculate the Euclidean distance between two embeddings
def calc_distance(embedding1, embedding2):
    return float(np.linalg.norm(embedding1 - embedding2))
